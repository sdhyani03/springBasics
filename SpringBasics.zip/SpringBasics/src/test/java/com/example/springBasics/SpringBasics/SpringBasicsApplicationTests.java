package com.example.springBasics.SpringBasics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBasicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
